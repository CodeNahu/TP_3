#ifndef __LINKEDLIST
#define __LINKEDLIST
struct Node
{
    void* pElement;
    struct Node* pNextNode;
}typedef Node;

struct LinkedList
{
    Node* pFirstNode;
    int size;
}typedef LinkedList;
#endif



LinkedList* ll_newLinkedList(void); //crea linked list
int ll_len(LinkedList* this);
Node* test_getNode(LinkedList* this, int nodeIndex); //
int test_addNode(LinkedList* this, int nodeIndex,void* pElement);
int ll_add(LinkedList* this, void* pElement);//agrega un elemento
void* ll_get(LinkedList* this, int index);
int ll_set(LinkedList* this, int index,void* pElement); //pisa un elemento
int ll_remove(LinkedList* this,int index);// elimina elemento
int ll_clear(LinkedList* this);// limpia
int ll_deleteLinkedList(LinkedList* this);// libera la memoria
int ll_indexOf(LinkedList* this, void* pElement);
int ll_isEmpty(LinkedList* this); // dice si esta libre o no
int ll_push(LinkedList* this, int index, void* pElement);
void* ll_pop(LinkedList* this,int index);
int ll_contains(LinkedList* this, void* pElement); // dice si esta el elemento o no
int ll_containsAll(LinkedList* this,LinkedList* this2); // dice si los elementeo de una linked list estan en el primero
LinkedList* ll_subList(LinkedList* this,int from,int to); //crea un subconjunto de esa linked list
LinkedList* ll_clone(LinkedList* this); // clona la linkedlist y devuelve el primer elemento de la linkedlist
int ll_sort(LinkedList* this, int (*pFunc)(void* ,void*), int order); // ordenamiento de la linked list
